import tkinter as tk
from tkinter import ttk

class KFMCCentersApp:
    def __init__(self, root):
        self.root = root
        self.setup_window()
        self.create_styles()
        self.create_widgets()
        self.load_kfmc_centers()
        
    def setup_window(self):
        self.root.title("KFMC Healthcare Centers")
        self.root.geometry("800x600")
        self.root.configure(bg="#f5f9ff")
        
    def create_styles(self):
        self.style = ttk.Style()
        
        primary_blue = "#005b96"
        secondary_blue = "#1a5276"
        light_blue = "#e6f0ff"
        
        self.style.configure("Title.TLabel", 
                           font=("Helvetica", 20, "bold"),
                           foreground=primary_blue,
                           background="#f5f9ff",
                           padding=10)
        
        self.style.configure("Treeview.Heading", 
                           font=("Helvetica", 12, "bold"),
                           foreground="white",
                           background=primary_blue,
                           relief="flat")
        
        self.style.configure("Treeview",
                           font=("Helvetica", 11),
                           rowheight=30,
                           background="white",
                           fieldbackground="white",
                           bordercolor="#d9e2ff")
        
        self.style.map("Treeview",
                     background=[('selected', secondary_blue)])
        
    def create_widgets(self):
        # Main container
        main_frame = tk.Frame(self.root, bg="#f5f9ff")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=40, pady=40)
        
        # Title
        title_frame = tk.Frame(main_frame, bg="#f5f9ff")
        title_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(title_frame, 
                text="King Fahad Medical City", 
                font=("Helvetica", 20, "bold"),
                fg="#005b96",
                bg="#f5f9ff").pack()
        
        tk.Label(title_frame, 
                text="Healthcare Centers Directory", 
                font=("Helvetica", 14),
                fg="#7b8db0",
                bg="#f5f9ff").pack(pady=(5, 0))
        
        ttk.Separator(main_frame, orient="horizontal").pack(fill=tk.X, pady=10)
        
        tree_frame = tk.Frame(main_frame, bg="#f5f9ff")
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        self.tree = ttk.Treeview(tree_frame, 
                                columns=("center", "location"), 
                                show="headings")
        
        self.tree.heading("center", text="Medical Center", anchor=tk.W)
        self.tree.heading("location", text="Location in KFMC", anchor=tk.W)
        self.tree.column("center", width=450, anchor="w")
        self.tree.column("location", width=300, anchor="w")
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree.tag_configure('evenrow', background='white')
        self.tree.tag_configure('oddrow', background='#f9fbff')
    
    def load_kfmc_centers(self):
        """Load all centers within KFMC main campus"""
        kfmc_centers = [
            ("Main Hospital Building", "Central Tower"),
            ("Children's Specialty Hospital", "North Wing"),
            ("Oncology Center", "East Wing, Level 3"),
            ("Cardiac Center", "East Wing, Level 2"),
            ("Neuroscience Institute", "West Wing, Level 4"),
            ("Rehabilitation Hospital", "South Wing"),
            ("Outpatient Clinics", "Ground Floor, Main Building"),
            ("Research Center", "Administration Building"),
            ("Women's Specialty Hospital", "West Wing, Level 2"),
            ("Emergency Hospital", "North Entrance"),
            ("Dental Center", "Ground Floor, East Wing"),
            ("Eye Specialist Center", "West Wing, Level 3"),
            ("Kidney Center", "East Wing, Level 1"),
            ("Bone Marrow Transplant Unit", "East Wing, Level 4"),
            ("Burn Center", "South Wing, Level 1")
        ]
        
        for i, (center, location) in enumerate(kfmc_centers):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.tree.insert("", tk.END, values=(center, location), tags=(tag,))

def show():
    root = tk.Tk()
    app = KFMCCentersApp(root)
    root.mainloop()

if __name__ == "__main__":
    show()