import tkinter as tk
from tkinter import ttk, messagebox
import os
from database import create_connection
from theme import Theme

def show(parent=None):
    # تهيئة الأنماط
    Theme.configure_styles()
    
    register_window = tk.Toplevel(parent) if parent else tk.Tk()
    register_window.title("Student Registration - King Fahad Medical City")
    register_window.geometry("700x900")
    register_window.configure(bg=Theme.LIGHT)
    
    # إطار رئيسي مع تمرير
    main_frame = ttk.Frame(register_window, style="TFrame")
    main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
    
    canvas = tk.Canvas(main_frame, bg=Theme.LIGHT, highlightthickness=0)
    scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = ttk.Frame(canvas, style="TFrame")
    
    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )
    
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    
    # العنوان
    header_frame = ttk.Frame(scrollable_frame, style="Header.TFrame", padding=20)
    header_frame.pack(fill=tk.X, pady=(0, 20))
    
    tk.Label(header_frame, 
             text="King Fahad Medical City\nمدينة الملك فهد الطبية",
             font=("Cairo", 16, "bold"),
             bg=Theme.PRIMARY,
             fg=Theme.WHITE,
             justify="center").pack()
    
    tk.Label(header_frame, 
             text="Student Registration\nتسجيل الطالب",
             font=("Cairo", 12, "bold"),
             bg=Theme.PRIMARY,
             fg="#f39c12",
             justify="center").pack(pady=5)
    
    # حقول النموذج
    form_frame = ttk.Frame(scrollable_frame, style="Card.TFrame", padding=20)
    form_frame.pack(fill=tk.X, pady=10)
    
    fields = [
        ("name_ar", "الاسم بالعربية / Name (Arabic)"),
        ("name_en", "الاسم بالإنجليزية / Name (English)"),
        ("national_id", "رقم الهوية الوطنية / National ID"),
        ("age", "العمر / Age"),
        ("mobile", "رقم الجوال / Mobile"),
        ("email", "البريد الإلكتروني / Email"),
        ("country", "الجنسية / Country"),
        ("gender", "الجنس / Gender"),
        ("university", "اسم الجامعة / University Name"),
        ("student_id", "رقم الطالب الجامعي / Student ID"),
        ("major", "التخصص / Major"),
        ("degree", "الدرجة العلمية / Degree"),
        ("start_date", "تاريخ بدء التدريب / Training Start Date"),
        ("end_date", "تاريخ انتهاء التدريب / Training End Date"),
        ("supervisor_name", "اسم المشرف الأكاديمي / Academic Supervisor Name"),
        ("supervisor_email", "بريد المشرف الأكاديمي / Academic Supervisor Email")
    ]
    
    entries = {}
    for i, (field, label_text) in enumerate(fields):
        row_frame = ttk.Frame(form_frame, style="TFrame")
        row_frame.pack(fill=tk.X, pady=8)
        
        tk.Label(row_frame, text=label_text, bg=Theme.WHITE, 
                font=("Cairo", 10, "bold")).pack(side=tk.LEFT, anchor="w", padx=(0, 10))
        
        entry = ttk.Entry(row_frame, width=30, font=("Cairo", 10))
        entry.pack(side=tk.RIGHT, fill=tk.X, expand=True)
        entries[field] = entry
    
    # حقول اختيار الجنس
    gender_frame = ttk.Frame(form_frame, style="TFrame")
    gender_frame.pack(fill=tk.X, pady=8)
    
    tk.Label(gender_frame, text="الجنس / Gender", bg=Theme.WHITE, 
            font=("Cairo", 10, "bold")).pack(side=tk.LEFT, anchor="w", padx=(0, 10))
    
    gender_var = tk.StringVar(value="Male")
    gender_choice_frame = ttk.Frame(gender_frame, style="TFrame")
    gender_choice_frame.pack(side=tk.RIGHT, fill=tk.X, expand=True)
    
    tk.Radiobutton(gender_choice_frame, text="ذكر / Male", variable=gender_var, value="Male", 
                  bg=Theme.WHITE, font=("Cairo", 10)).pack(side=tk.LEFT)
    tk.Radiobutton(gender_choice_frame, text="أنثى / Female", variable=gender_var, value="Female", 
                  bg=Theme.WHITE, font=("Cairo", 10)).pack(side=tk.LEFT, padx=20)
    entries["gender"] = gender_var
    
    # رفع الملفات
    file_paths = {"training_letter": "", "cv": ""}
    
    def choose_file(field_name, field_label):
        path = tk.filedialog.askopenfilename(title=f"Select {field_label}")
        if path:
            file_paths[field_name] = path
            messagebox.showinfo("تم اختيار الملف", f"تم اختيار: {os.path.basename(path)}")
    
    # خطاب التدريب
    training_frame = ttk.Frame(form_frame, style="TFrame")
    training_frame.pack(fill=tk.X, pady=8)
    
    tk.Label(training_frame, text="خطاب التدريب التعاوني / Training Letter", 
             bg=Theme.WHITE, font=("Cairo", 10, "bold")).pack(side=tk.LEFT, anchor="w", padx=(0, 10))
    
    ttk.Button(training_frame, text="اختر ملف / Choose File", 
              command=lambda: choose_file("training_letter", "Training Letter")).pack(side=tk.RIGHT)
    
    # السيرة الذاتية
    cv_frame = ttk.Frame(form_frame, style="TFrame")
    cv_frame.pack(fill=tk.X, pady=8)
    
    tk.Label(cv_frame, text="السيرة الذاتية / CV", 
             bg=Theme.WHITE, font=("Cairo", 10, "bold")).pack(side=tk.LEFT, anchor="w", padx=(0, 10))
    
    ttk.Button(cv_frame, text="اختر ملف / Choose File", 
              command=lambda: choose_file("cv", "CV")).pack(side=tk.RIGHT)
    
    # زر التسجيل
    def submit():
        data = {}
        for field, entry in entries.items():
            if isinstance(entry, tk.StringVar):
                data[field] = entry.get()
            else:
                data[field] = entry.get()
        
        data.update(file_paths)
        
        # التحقق من الحقول المطلوبة
        required_fields = ["name_ar", "name_en", "national_id", "email", "university", 
                          "major", "start_date", "end_date", "supervisor_name", "supervisor_email"]
        
        missing_fields = [field for field in required_fields if not data.get(field)]
        if missing_fields:
            messagebox.showerror("خطأ", "يرجى ملء جميع الحقول الإلزامية")
            return
        
        if not data["training_letter"] or not data["cv"]:
            messagebox.showerror("خطأ", "يرجى رفع خطاب التدريب والسيرة الذاتية")
            return
        
        # حفظ البيانات في قاعدة البيانات
        try:
            conn = create_connection()
            c = conn.cursor()
            
            c.execute('''
                INSERT INTO students (
                    name_ar, name_en, national_id, age, mobile, email,
                    country, gender, university, student_id, major, degree,
                    start_date, end_date, supervisor_name, supervisor_email,
                    training_letter, cv, status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data["name_ar"], data["name_en"], data["national_id"], data["age"],
                data["mobile"], data["email"], data["country"], data["gender"],
                data["university"], data["student_id"], data["major"], data["degree"],
                data["start_date"], data["end_date"], data["supervisor_name"],
                data["supervisor_email"], data["training_letter"], data["cv"], "Pending"
            ))
            
            conn.commit()
            conn.close()
            
            messagebox.showinfo("نجاح", "تم تسجيل طلبك بنجاح وسيتم المراجعة")
            register_window.destroy()
            
        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء التسجيل: {str(e)}")
    
    submit_btn = tk.Button(scrollable_frame, 
                          text="تسجيل / Submit",
                          command=submit,
                          bg=Theme.SUCCESS,
                          fg=Theme.WHITE,
                          font=("Cairo", 12, "bold"),
                          padx=30,
                          pady=10,
                          relief=tk.FLAT,
                          cursor="hand2")
    submit_btn.pack(pady=20)
    
    if not parent:
        register_window.mainloop()