import tkinter as tk
from tkinter import ttk, messagebox
from database import create_connection
from email_utils import send_email

def show_admin_page(parent=None):
    login_window = tk.Toplevel(parent) if parent else tk.Tk()
    login_window.title("Admin Login - King Fahad Medical City")
    login_window.geometry("400x300")
    login_window.configure(bg="#f0f2f5")
    
    login_frame = tk.Frame(login_window, bg="#f0f2f5", padx=30, pady=30)
    login_frame.pack(expand=True, fill="both")
    
    tk.Label(login_frame, 
             text="Admin Login\nتسجيل الدخول للمسؤول",
             font=("Arial", 16, "bold"),
             bg="#f0f2f5").pack(pady=20)
    
    tk.Label(login_frame, 
             text="اسم المستخدم / Username:",
             font=("Arial", 10),
             bg="#f0f2f5").pack(anchor="w")
    username_entry = ttk.Entry(login_frame, font=("Arial", 12))
    username_entry.pack(fill="x", pady=5)
    
    tk.Label(login_frame, 
             text="كلمة المرور / Password:",
             font=("Arial", 10),
             bg="#f0f2f5").pack(anchor="w")
    password_entry = ttk.Entry(login_frame, show="*", font=("Arial", 12))
    password_entry.pack(fill="x", pady=5)
    
    def login():
        username = username_entry.get()
        password = password_entry.get()
        
        try:
            conn = create_connection()
            c = conn.cursor()
            c.execute("SELECT * FROM admins WHERE username=? AND password=?", (username, password))
            admin = c.fetchone()
            conn.close()
            
            if admin:
                login_window.destroy()
                show_admin_dashboard(parent)
            else:
                messagebox.showerror("خطأ", "بيانات الدخول غير صحيحة")
        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء الدخول: {str(e)}")
    
    login_btn = tk.Button(login_frame,
                         text="دخول / Login",
                         command=login,
                         bg="#1877f2",
                         fg="white",
                         font=("Arial", 12, "bold"),
                         padx=20,
                         pady=5)
    login_btn.pack(pady=20, fill="x")
    
    if not parent:
        login_window.mainloop()

def show_admin_dashboard(parent=None):
    admin_window = tk.Toplevel(parent) if parent else tk.Tk()
    admin_window.title("Admin Dashboard - Training System")
    admin_window.geometry("1200x800")
    admin_window.configure(bg="#f0f2f5")
    
    header_frame = tk.Frame(admin_window, bg="#1877f2", padx=20, pady=15)
    header_frame.pack(fill="x")
    
    tk.Label(header_frame,
             text="Training System - Admin Dashboard\nنظام التدريب - لوحة تحكم المسؤول",
             font=("Arial", 16, "bold"),
             bg="#1877f2",
             fg="white").pack(side="left")
    
    # إطار رئيسي
    main_frame = tk.Frame(admin_window, bg="#f0f2f5")
    main_frame.pack(fill="both", expand=True, padx=20, pady=20)
    
    # شجرة لعرض الطلبات
    tree_frame = tk.Frame(main_frame, bg="#ffffff", relief=tk.GROOVE, bd=1)
    tree_frame.pack(fill="both", expand=True)
    
    columns = ("id", "name_ar", "name_en", "university", "major", "status", "interview")
    tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=20)
    
    # عناوين الأعمدة
    tree.heading("id", text="ID")
    tree.heading("name_ar", text="الاسم بالعربية")
    tree.heading("name_en", text="الاسم بالإنجليزية")
    tree.heading("university", text="الجامعة")
    tree.heading("major", text="التخصص")
    tree.heading("status", text="الحالة")
    tree.heading("interview", text="موعد المقابلة")
    
    # تحديد عرض الأعمدة
    tree.column("id", width=50, anchor="center")
    tree.column("name_ar", width=150, anchor="w")
    tree.column("name_en", width=150, anchor="w")
    tree.column("university", width=150, anchor="w")
    tree.column("major", width=150, anchor="w")
    tree.column("status", width=100, anchor="center")
    tree.column("interview", width=120, anchor="center")
    
    # شريط التمرير
    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    tree.pack(fill="both", expand=True)
    
    # زر تحديث البيانات
    def refresh_data():
        for item in tree.get_children():
            tree.delete(item)
        
        conn = create_connection()
        c = conn.cursor()
        c.execute("SELECT id, name_ar, name_en, university, major, status, interview_date FROM students")
        for row in c.fetchall():
            tree.insert("", "end", values=row)
        conn.close()
    
    # إطار الأزرار
    button_frame = tk.Frame(main_frame, bg="#f0f2f5", pady=15)
    button_frame.pack(fill="x")
    
    refresh_btn = tk.Button(button_frame,
                          text="تحديث / Refresh",
                          command=refresh_data,
                          bg="#42b72a",
                          fg="white",
                          font=("Arial", 10, "bold"),
                          padx=15,
                          pady=5)
    refresh_btn.pack(side="left", padx=5)
    
    # زر ترشيح للمقابلة
    def schedule_interview():
        selected = tree.focus()
        if not selected:
            messagebox.showwarning("تحذير", "يرجى اختيار طالب أولاً")
            return
        
        student_data = tree.item(selected)['values']
        student_id = student_data[0]
        
        # نافذة تحديد موعد المقابلة
        interview_win = tk.Toplevel(admin_window)
        interview_win.title("Schedule Interview")
        interview_win.geometry("400x300")
        
        tk.Label(interview_win, 
                 text=f"تحديد موعد مقابلة للطالب: {student_data[1]}",
                 font=("Arial", 14, "bold")).pack(pady=15)
        
        tk.Label(interview_win, text="تاريخ المقابلة (YYYY-MM-DD):").pack()
        date_entry = ttk.Entry(interview_win)
        date_entry.pack(pady=5, padx=20, fill="x")
        
        tk.Label(interview_win, text="وقت المقابلة (HH:MM):").pack()
        time_entry = ttk.Entry(interview_win)
        time_entry.pack(pady=5, padx=20, fill="x")
        
        def confirm_interview():
            interview_date = f"{date_entry.get()} الساعة {time_entry.get()}"
            
            conn = create_connection()
            c = conn.cursor()
            c.execute("UPDATE students SET status=?, interview_date=? WHERE id=?",
                     ("Interview Scheduled", interview_date, student_id))
            conn.commit()
            
            # إرسال بريد إلكتروني للطالب
            c.execute("SELECT email FROM students WHERE id=?", (student_id,))
            student_email = c.fetchone()[0]
            conn.close()
            
            email_subject = "دعوة لمقابلة تدريبية - مدينة الملك فهد الطبية"
            email_body = f"""
بعد التحية

نفيدكم بأنه تم ترشيحكم لمقابلة تدريبية في مدينة الملك فهد الطبية

موعد المقابلة: {interview_date}

الرجاء احضار:
- السيرة الذاتية
- نسخة من خطاب الجامعة

عنوان المدينة: مدينة الملك فهد الطبية، كلية الطب، الدور الثاني

مع تحياتنا،
إدارة التدريب
مدينة الملك فهد الطبية
"""
            if send_email(student_email, email_subject, email_body):
                messagebox.showinfo("نجاح", "تم تحديد موعد المقابلة وإرسال البريد الإلكتروني")
            else:
                messagebox.showwarning("تحذير", "تم تحديد موعد المقابلة ولكن فشل إرسال البريد الإلكتروني")
            
            interview_win.destroy()
            refresh_data()
        
        confirm_btn = tk.Button(interview_win,
                              text="تأكيد / Confirm",
                              command=confirm_interview,
                              bg="#1877f2",
                              fg="white",
                              font=("Arial", 10, "bold"),
                              padx=20,
                              pady=5)
        confirm_btn.pack(pady=15)
    
    interview_btn = tk.Button(button_frame,
                            text="ترشيح للمقابلة / Schedule Interview",
                            command=schedule_interview,
                            bg="#1877f2",
                            fg="white",
                            font=("Arial", 10, "bold"),
                            padx=15,
                            pady=5)
    interview_btn.pack(side="left", padx=5)
    
    # زر قبول الطلب
    def accept_application():
        selected = tree.focus()
        if not selected:
            messagebox.showwarning("تحذير", "يرجى اختيار طالب أولاً")
            return
        
        student_data = tree.item(selected)['values']
        student_id = student_data[0]
        
        conn = create_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM students WHERE id=?", (student_id,))
        student = c.fetchone()
        
        # تحديث حالة الطلب
        c.execute("UPDATE students SET status=? WHERE id=?",
                 ("Accepted", student_id))
        conn.commit()
        
        # إرسال بريد القبول
        email_subject = "قبول طلب التدريب - مدينة الملك فهد الطبية"
        email_body = f"""
بعد التحية

نفيدكم بأنه لا مانع لدينا من قبول تدريب المتدرب/ة {student[1]}
تخصص: {student[11]}
الرقم الجامعي: {student[10]}
في: مدينة الملك فهد الطبية
ابتداء من {student[13]}
وإنتهاء {student[14]}

مع تحياتنا،
إدارة التدريب
مدينة الملك فهد الطبية
"""
        
        # إرسال البريد للطالب والمشرف
        student_email = student[6]
        supervisor_email = student[16]
        
        student_sent = send_email(student_email, email_subject, email_body)
        supervisor_sent = send_email(supervisor_email, email_subject, email_body)
        
        if student_sent and supervisor_sent:
            messagebox.showinfo("نجاح", "تم قبول الطلب وإرسال البريد الإلكتروني للطالب والمشرف")
        else:
            messagebox.showwarning("تحذير", "تم قبول الطلب ولكن فشل إرسال بعض رسائل البريد الإلكتروني")
        
        conn.close()
        refresh_data()
    
    accept_btn = tk.Button(button_frame,
                          text="قبول الطلب / Accept Application",
                          command=accept_application,
                          bg="#42b72a",
                          fg="white",
                          font=("Arial", 10, "bold"),
                          padx=15,
                          pady=5)
    accept_btn.pack(side="left", padx=5)
    
    # زر رفض الطلب
    def reject_application():
        selected = tree.focus()
        if not selected:
            messagebox.showwarning("تحذير", "يرجى اختيار طالب أولاً")
            return
        
        student_data = tree.item(selected)['values']
        student_id = student_data[0]
        
        conn = create_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM students WHERE id=?", (student_id,))
        student = c.fetchone()
        
        # تحديث حالة الطلب
        c.execute("UPDATE students SET status=? WHERE id=?",
                 ("Rejected", student_id))
        conn.commit()
        
        # إرسال بريد الرفض
        email_subject = "قرار بشأن طلب التدريب - مدينة الملك فهد الطبية"
        email_body = """
بعد التحية

نعتذر عن قبول طلبكم للتدريب لعدم توفر شواغر في الوقت الحالي.

مع تحياتنا،
إدارة التدريب
مدينة الملك فهد الطبية
"""
        
        student_email = student[6]
        send_email(student_email, email_subject, email_body)
        
        conn.close()
        messagebox.showinfo("نجاح", "تم رفض الطلب وإرسال البريد الإلكتروني")
        refresh_data()
    
    reject_btn = tk.Button(button_frame,
                          text="رفض الطلب / Reject Application",
                          command=reject_application,
                          bg="#e74c3c",
                          fg="white",
                          font=("Arial", 10, "bold"),
                          padx=15,
                          pady=5)
    reject_btn.pack(side="left", padx=5)
    
    # تحميل البيانات الأولية
    refresh_data()
    
    if not parent:
        admin_window.mainloop()