import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import os

id_badge_path = ""

def open_clearance_page():
    global id_badge_path   
    
    root = tk.Tk()
    root.title("نموذج إخلاء الطرف - مدينة الملك فهد الطبية")
    root.geometry("1000x900")
    root.configure(bg="#f5f5f5")
    
    style = ttk.Style()
    style.configure("TLabel", background="#f5f5f5", font=("Arial", 10))
    style.configure("TEntry", font=("Arial", 10), padding=5)
    style.configure("TRadiobutton", background="#f5f5f5", font=("Arial", 10))
    style.configure("TCombobox", padding=5)
    
    main_frame = tk.Frame(root, bg="#f5f5f5")
    main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
    
    canvas = tk.Canvas(main_frame, bg="#f5f5f5", highlightthickness=0)
    scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas, bg="#f5f5f5")
    
    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )
    
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    
    # Header Section
    header_frame = tk.Frame(scrollable_frame, bg="#2c3e50", padx=20, pady=15)
    header_frame.pack(fill=tk.X, pady=(0, 20))
    
    tk.Label(header_frame, 
             text="King Fahad Medical City\nمدينة الملك فهد الطبية",
             font=("Arial", 16, "bold"),
             bg="#2c3e50",
             fg="white",
             justify="center").pack()
    
    tk.Label(header_frame, 
             text="Clearance (For Non KFMC staff)\nإخلاء طرف (لغير موظفي المدينة)",
             font=("Arial", 12, "bold"),
             bg="#2c3e50",
             fg="#f39c12",
             justify="center").pack(pady=5)
    
    # Form Title
    tk.Label(scrollable_frame, 
             text="Clearance Form\nنموذج إخلاء الطرف",
             font=("Arial", 14, "bold"),
             bg="#f5f5f5",
             justify="center").pack(pady=10)
    
    # Form Section
    form_frame = tk.Frame(scrollable_frame, bg="#ecf0f1", padx=15, pady=15, relief=tk.GROOVE, bd=1)
    form_frame.pack(fill=tk.X, pady=10)
    
    # Current date
    today = datetime.now().strftime("%Y-%m-%d")
    tk.Label(form_frame, text="Date / التاريخ", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky="w", pady=5)
    tk.Label(form_frame, text=today, bg="#ecf0f1", font=("Arial", 10)).grid(row=0, column=1, sticky="w")
    
    # Administration Name
    tk.Label(form_frame, text="Administration Name / اسم الإدارة", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=1, column=0, sticky="w", pady=5)
    admin_options = [
        "Management Training Administration",
        "Medical Training Administration",
        "Health Training Administration",
        "Nursing Education Administration",
        "Volunteer Administration",
        "Contracting/Outsourcing",
        "Family Medicine Academy",
        "Health Care Security",
        "Radiology AAML Administration"
    ]
    
    admin_var = tk.StringVar()
    admin_dropdown = ttk.Combobox(form_frame, textvariable=admin_var, values=admin_options, 
                                 font=("Arial", 10), width=40, state="readonly")
    admin_dropdown.grid(row=1, column=1, sticky="w", columnspan=2)
    
    # Employee Number
    tk.Label(form_frame, text="Employee No. / رقم الموظف", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=2, column=0, sticky="w", pady=5)
    emp_no_entry = ttk.Entry(form_frame, width=30, font=("Arial", 10))
    emp_no_entry.grid(row=2, column=1, sticky="w")
    
    # Housing question
    tk.Label(form_frame, text="Have housing? / هل لديك سكن؟", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=3, column=0, sticky="w", pady=5)
    housing_frame = tk.Frame(form_frame, bg="#ecf0f1")
    housing_frame.grid(row=3, column=1, sticky="w")
    
    housing_var = tk.StringVar(value="No")
    tk.Radiobutton(housing_frame, text="Yes / نعم", variable=housing_var, value="Yes", 
                  bg="#ecf0f1", font=("Arial", 10)).pack(side="left")
    tk.Radiobutton(housing_frame, text="No / لا", variable=housing_var, value="No", 
                  bg="#ecf0f1", font=("Arial", 10)).pack(side="left", padx=10)
    
    ttk.Separator(scrollable_frame, orient="horizontal").pack(fill=tk.X, pady=15)
    
    # Personal Information Section
    personal_frame = tk.Frame(scrollable_frame, bg="#ecf0f1", padx=15, pady=15, relief=tk.GROOVE, bd=1)
    personal_frame.pack(fill=tk.X, pady=10)
    
    # Nationality
    tk.Label(personal_frame, text="Nationality / الجنسية", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky="w", pady=5)
    nationality_frame = tk.Frame(personal_frame, bg="#ecf0f1")
    nationality_frame.grid(row=0, column=1, sticky="w")
    
    nationality_var = tk.StringVar()
    tk.Radiobutton(nationality_frame, text="Saudi / سعودي", variable=nationality_var, value="Saudi", 
                  bg="#ecf0f1", font=("Arial", 10)).pack(side="left")
    tk.Radiobutton(nationality_frame, text="Non Saudi / غير سعودي", variable=nationality_var, value="Non Saudi", 
                  bg="#ecf0f1", font=("Arial", 10)).pack(side="left", padx=10)
    
    # ID Number
    tk.Label(personal_frame, text="ID Number/gamma / السجل المدني/الإقامة", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=1, column=0, sticky="w", pady=5)
    id_entry = ttk.Entry(personal_frame, width=30, font=("Arial", 10))
    id_entry.grid(row=1, column=1, sticky="w")
    
    # English Name
    tk.Label(personal_frame, text="English Name / الاسم بالإنجليزية", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=2, column=0, sticky="w", pady=5)
    eng_name_entry = ttk.Entry(personal_frame, width=30, font=("Arial", 10))
    eng_name_entry.grid(row=2, column=1, sticky="w")
    
    # Arabic Name
    tk.Label(personal_frame, text="Arabic Name / الاسم بالعربية", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=3, column=0, sticky="w", pady=5)
    arabic_name_entry = ttk.Entry(personal_frame, width=30, font=("Arial", 10))
    arabic_name_entry.grid(row=3, column=1, sticky="w")
    
    # ID Badge Section
    tk.Label(personal_frame, text="ID Badge / بطاقة الموظف", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=4, column=0, sticky="w", pady=5)
    
    def upload_id_file():
        global id_badge_path
        file_path = filedialog.askopenfilename(
            title="Select ID Badge File / اختر ملف بطاقة الموظف",
            filetypes=[("PDF Files", "*.pdf"), ("Image Files", "*.jpg *.jpeg *.png"), ("All Files", "*.*")]
        )
        if file_path:
            id_badge_path = file_path
            file_name = os.path.basename(file_path)
            file_size = os.path.getsize(file_path) / 1024  
            file_info.config(text=f"تم رفع الملف: {file_name} ({file_size:.1f} KB)")
    
    upload_btn = tk.Button(personal_frame, 
                          text="Upload ID Badge / رفع ملف البطاقة",
                          command=upload_id_file,
                          bg="#3498db",
                          fg="white",
                          font=("Arial", 10),
                          padx=10,
                          pady=5)
    upload_btn.grid(row=4, column=1, sticky="w", pady=5)
    
    file_info = tk.Label(personal_frame, 
                        text="لم يتم رفع أي ملف بعد",
                        bg="#ecf0f1",
                        fg="#666",
                        font=("Arial", 9))
    file_info.grid(row=5, column=1, sticky="w")
    
    # ID Badge Expiry
    tk.Label(personal_frame, text="ID Badge Expiry date / تاريخ انتهاء البطاقة", bg="#ecf0f1", font=("Arial", 10, "bold")).grid(row=6, column=0, sticky="w", pady=5)
    expiry_entry = ttk.Entry(personal_frame, width=30, font=("Arial", 10))
    expiry_entry.grid(row=6, column=1, sticky="w")
    
    # Note section
    note_frame = tk.Frame(scrollable_frame, bg="#fff3cd", padx=15, pady=10, relief=tk.GROOVE, bd=1)
    note_frame.pack(fill=tk.X, pady=15)
    
    tk.Label(note_frame, 
             text="Note: Please attach your ID badge file (PDF or Image)",
             bg="#fff3cd",
             font=("Arial", 10, "bold")).pack(anchor="w")
    
    tk.Label(note_frame, 
             text="ملاحظة: يرجى إرفاق ملف بطاقة الموظف (PDF أو صورة)",
             bg="#fff3cd",
             font=("Arial", 10, "bold")).pack(anchor="w")
    
    # Submit button
    submit_frame = tk.Frame(scrollable_frame, bg="#f5f5f5", pady=20)
    submit_frame.pack()
    
    def submit_form():
        global id_badge_path
        required_fields = [
            (admin_var.get(), "Please select administration / يرجى اختيار الإدارة"),
            (emp_no_entry.get(), "Please enter employee number / يرجى إدخال رقم الموظف"),
            (nationality_var.get(), "Please select nationality / يرجى اختيار الجنسية"),
            (id_entry.get(), "Please enter ID number / يرجى إدخال رقم الهوية"),
            (eng_name_entry.get(), "Please enter English name / يرجى إدخال الاسم بالإنجليزية"),
            (arabic_name_entry.get(), "Please enter Arabic name / يرجى إدخال الاسم بالعربية"),
            (id_badge_path, "Please upload ID badge file / يرجى رفع ملف بطاقة الموظف")
        ]
        
        errors = [msg for value, msg in required_fields if not value]
        
        if errors:
            messagebox.showerror("Error / خطأ", "Please fix the following errors:\n\n• " + "\n• ".join(errors))
            return
        
        form_data = {
            "date": today,
            "administration": admin_var.get(),
            "employee_no": emp_no_entry.get(),
            "housing": housing_var.get(),
            "nationality": nationality_var.get(),
            "id_number": id_entry.get(),
            "english_name": eng_name_entry.get(),
            "arabic_name": arabic_name_entry.get(),
            "id_badge_file": id_badge_path,
            "id_expiry": expiry_entry.get()
        }
        
        messagebox.showinfo("Success / نجاح", "Clearance form submitted successfully!\nتم تقديم النموذج بنجاح")
        print("Form data:", form_data) 
        root.destroy()
    
    submit_btn = tk.Button(submit_frame, 
                          text="Submit Clearance / تقديم النموذج",
                          command=submit_form,
                          bg="#28a745",
                          fg="white",
                          font=("Arial", 12, "bold"),
                          padx=20,
                          pady=10)
    submit_btn.pack()
    
    root.mainloop()

if __name__ == "__main__":
    open_clearance_page()