import tkinter as tk
from tkinter import font as tkfont
from tkinter import PhotoImage
import os

def show_home_page():
    # إنشاء النافذة الرئيسية
    window = tk.Tk()
    window.title("Riyadh Second Health Cluster")
    window.geometry("1100x750")
    window.configure(bg="white")

    # استيراد الصفحات
    from pages.register_page import show as register_show
    from pages.admin_page import show_admin_page as admin_show
    from pages.centers_page import show as centers_show
    from pages.clearance_page import open_clearance_page

    top_blue_bar = tk.Frame(window, bg="#2980b9", height=15)
    top_blue_bar.pack(fill=tk.X, side=tk.TOP)

    
    nav_frame = tk.Frame(window, bg="#3498db", padx=20, pady=10)
    nav_frame.pack(fill=tk.X)

    # أزرار التنقل
    buttons = [
        ("Register", register_show),
        ("Admin", admin_show),
        ("Healthcare Centers", centers_show),
        ("Clearance", open_clearance_page)
    ]

    for text, command in buttons:
        btn = tk.Button(nav_frame, 
                      text=text,
                      command=command,
                      font=tkfont.Font(family="Arial", size=11, weight="bold"),
                      bg="#2980b9",
                      fg="white",
                      activebackground="#1a5276",
                      activeforeground="white",
                      relief=tk.FLAT,
                      padx=25,
                      pady=8,
                      bd=0)
        btn.pack(side=tk.LEFT, padx=15)

    # 3. إطار رئيسي للتمرير
    main_frame = tk.Frame(window, bg="white")
    main_frame.pack(fill=tk.BOTH, expand=True)

    canvas = tk.Canvas(main_frame, bg="white", highlightthickness=0)
    scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas, bg="white")

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    # 4. محتوى الصفحة
    header_frame = tk.Frame(scrollable_frame, bg="white", padx=20, pady=20)
    header_frame.pack(fill=tk.X)

    # قسم اللوجو
    logo_frame = tk.Frame(header_frame, bg="white")
    logo_frame.pack(side=tk.RIGHT)

    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        logo_path = os.path.join(current_dir, "logo.png")
        
        if os.path.exists(logo_path):
            logo_img = PhotoImage(file=logo_path)
            if logo_img.width() > 200:
                ratio = logo_img.width() / 200
                logo_img = logo_img.subsample(int(ratio), int(ratio))
            
            logo_label = tk.Label(logo_frame, image=logo_img, bg="white")
            logo_label.image = logo_img
            logo_label.pack()
        else:
            raise FileNotFoundError
    except Exception as e:
        print(f"Error loading logo: {e}")
        tk.Label(logo_frame,
                text="KFMC\nLogo",
                font=tkfont.Font(size=14, weight="bold"),
                bg="#e3f2fd",
                fg="#005b96",
                width=15,
                height=5,
                relief=tk.GROOVE).pack()

    # قسم العنوان
    title_frame = tk.Frame(header_frame, bg="white")
    title_frame.pack(expand=True)

    tk.Label(title_frame, 
            text="مدينة الملك فهد الطبية", 
            font=tkfont.Font(family="Arial", size=24, weight="bold"),
            bg="white",
            fg="#1a5276").pack()

    tk.Label(title_frame, 
            text="King Fahad Medical City", 
            font=tkfont.Font(family="Arial", size=18),
            bg="white",
            fg="#1a5276").pack()

    # 5. المحتوى الرئيسي
    content_frame = tk.Frame(scrollable_frame, bg="white", padx=40, pady=20)
    content_frame.pack(fill=tk.BOTH, expand=True)
 
    tk.Label(content_frame, 
            text="KFMC Mission:", 
            font=tkfont.Font(family="Arial", size=14, weight="bold"),
            bg="white",
            fg="#1a5276").pack(anchor=tk.W, pady=(0, 10))
    
    mission_text = """To implement digital transformation strategies that enhance beneficiaries' satisfaction, empower employees, ensure compliance, drive operational efficiency, increase technical continuity and enhance collaboration, while fostering innovation."""
    tk.Label(content_frame, 
            text=mission_text, 
            font=tkfont.Font(family="Arial", size=12),
            bg="white",
            wraplength=900,
            justify=tk.LEFT).pack(anchor=tk.W, pady=(0, 20))

    # قسم الرؤية
    tk.Label(content_frame, 
            text="KFMC Vision:", 
            font=tkfont.Font(family="Arial", size=14, weight="bold"),
            bg="white",
            fg="#1a5276").pack(anchor=tk.W, pady=(0, 10))
    
    vision_text = """To lead the transformation of specialized healthcare services through innovative, sustainable, and person-centric (beneficiary-employee) digital solutions that empower stakeholders and enhance accountability."""
    tk.Label(content_frame, 
            text=vision_text, 
            font=tkfont.Font(family="Arial", size=12),
            bg="white",
            wraplength=900,
            justify=tk.LEFT).pack(anchor=tk.W, pady=(0, 20))

    # قسم "من نحن"
    tk.Label(content_frame, 
            text="Who we are:", 
            font=tkfont.Font(family="Arial", size=14, weight="bold"),
            bg="white",
            fg="#1a5276").pack(anchor=tk.W, pady=(0, 10))
    
    who_text = """King Fahad Medical City "KFMC" started as a pioneering idea that came true. The idea was adopted by King Fahad bin Abdulaziz. The Prince of Riyadh region then, King Salman bin Abdulaziz laid the foundation stone of KFMC in 1403, corresponding to 1983. KFMC came into operation in the era of the Custodian of the Two Holy Mosques, King Fahad bin Abdulaziz, where King Abdullah bin Abdulaziz, Crown Prince then, inaugurated it on 21/08/1425 H, corresponding to 05/10/2004. KFMC has a strategic location in the heart of Riyadh city, capital of Saudi Arabia."""
    tk.Label(content_frame, 
            text=who_text, 
            font=tkfont.Font(family="Arial", size=12),
            bg="white",
            wraplength=900,
            justify=tk.LEFT).pack(anchor=tk.W, pady=(0, 20))

    # قسم معلومات الاتصال
    contact_frame = tk.Frame(content_frame, bg="#e3f2fd", padx=15, pady=15, relief=tk.GROOVE, bd=1)
    contact_frame.pack(fill=tk.X, pady=20)

    tk.Label(contact_frame, 
            text="Contact Information", 
            font=tkfont.Font(family="Arial", size=14, weight="bold"),
            bg="#e3f2fd",
            fg="#005b96").pack(anchor=tk.W, pady=(0, 10))

    contacts = [
        ("Address:", "King Fahad Medical City, Riyadh, Saudi Arabia"),
        ("Phone:", "+966 11 288 9999"),
        ("Email:", "info@kfmc.med.sa"),
        ("Website:", "www.kfmc.med.sa"),
        ("Emergency:", "911")
    ]

    for label, value in contacts:
        contact_row = tk.Frame(contact_frame, bg="#e3f2fd")
        contact_row.pack(anchor=tk.W, pady=2)
        
        tk.Label(contact_row, 
                text=label, 
                font=tkfont.Font(family="Arial", size=12, weight="bold"),
                bg="#e3f2fd",
                fg="#0077b6",
                width=10,
                anchor="e").grid(row=0, column=0, sticky="e")
        
        tk.Label(contact_row, 
                text=value, 
                font=tkfont.Font(family="Arial", size=12),
                bg="#e3f2fd",
                fg="#333333").grid(row=0, column=1, sticky="w")

    window.mainloop()

if __name__ == "__main__":
    show_home_page()