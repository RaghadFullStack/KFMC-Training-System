import smtplib
from email.mime.text import MIMEText
from email.header import Header

def send_email(to_email, subject, body):
    try:
        # إعدادات البريد الإلكتروني - يجب تحديثها بإعدادات البريد الفعلية
        sender_email = "raghad.comput.sci@gmail.com"
        sender_password = "A"
        
        # تكوين الرسالة
        msg = MIMEText(body, 'plain', 'utf-8')
        msg['Subject'] = Header(subject, 'utf-8')
        msg['From'] = sender_email
        msg['To'] = to_email

        # إرسال البريد
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.ehlo()
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, [to_email], msg.as_string())
        
        return True
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False