import tkinter as tk
from tkinter import ttk

class Theme:
    PRIMARY = "#2c3e50"       
    SECONDARY = "#3498db"     
    ACCENT = "#e74c3c"        
    SUCCESS = "#2ecc71"       
    WARNING = "#f39c12"       
    LIGHT = "#ecf0f1"         
    DARK = "#2c3e50"          
    WHITE = "#ffffff"         
    
   
    FONT_PRIMARY = ("Cairo", 10)
    FONT_HEADING = ("Cairo", 14, "bold")
    FONT_TITLE = ("Cairo", 18, "bold")
    
    @staticmethod
    def configure_styles():
        style = ttk.Style()
        
        style.configure("TFrame", background=Theme.LIGHT)
        style.configure("TLabel", background=Theme.LIGHT, font=Theme.FONT_PRIMARY)
        style.configure("TButton", font=Theme.FONT_PRIMARY)
        style.configure("TEntry", font=Theme.FONT_PRIMARY)
        style.configure("TCombobox", font=Theme.FONT_PRIMARY)
        
        style.configure("Primary.TButton", 
                       background=Theme.PRIMARY, 
                       foreground=Theme.WHITE,
                       font=Theme.FONT_PRIMARY,
                       padding=10)
        
        style.configure("Success.TButton", 
                       background=Theme.SUCCESS, 
                       foreground=Theme.WHITE,
                       font=Theme.FONT_PRIMARY,
                       padding=10)
        
        style.configure("Warning.TButton", 
                       background=Theme.WARNING, 
                       foreground=Theme.WHITE,
                       font=Theme.FONT_PRIMARY,
                       padding=10)
        
        style.configure("Danger.TButton", 
                       background=Theme.ACCENT, 
                       foreground=Theme.WHITE,
                       font=Theme.FONT_PRIMARY,
                       padding=10)
        
        style.configure("Card.TFrame", 
                       background=Theme.WHITE, 
                       relief="raised",
                       borderwidth=1)
        
        style.configure("Header.TFrame", 
                       background=Theme.PRIMARY)