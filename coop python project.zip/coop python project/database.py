import sqlite3
from pathlib import Path


Path("data").mkdir(exist_ok=True)

def create_connection():
    """إنشاء اتصال بقاعدة البيانات"""
    conn = sqlite3.connect('data/coop_db.sqlite')
    create_tables(conn)
    return conn

def create_tables(conn):
    """إنشاء الجداول إذا لم تكن موجودة"""
    c = conn.cursor()
    
    # جدول الطلاب
    c.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name_ar TEXT,
            name_en TEXT,
            national_id TEXT,
            age INTEGER,
            mobile TEXT,
            email TEXT,
            country TEXT,
            gender TEXT,
            university TEXT,
            student_id TEXT,
            major TEXT,
            degree TEXT,
            start_date TEXT,
            end_date TEXT,
            supervisor_name TEXT,
            supervisor_email TEXT,
            training_letter TEXT,
            cv TEXT,
            status TEXT DEFAULT 'Pending',
            interview_date TEXT
        )
    ''')
    
    
    try:
        c.execute("PRAGMA table_info(students)")
        columns = [column[1] for column in c.fetchall()]
        
        if 'status' not in columns:
            c.execute("ALTER TABLE students ADD COLUMN status TEXT DEFAULT 'Pending'")
            print("تم إضافة عمود status إلى جدول students")
            
        if 'interview_date' not in columns:
            c.execute("ALTER TABLE students ADD COLUMN interview_date TEXT")
            print("تم إضافة عمود interview_date إلى جدول students")
            
    except Exception as e:
        print(f"خطأ في تحديث الجدول: {e}")
    
    # جدول المسؤولين
    c.execute('''
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )
    ''')
    
    c.execute("SELECT COUNT(*) FROM admins")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO admins (username, password) VALUES (?, ?)", 
                 ("admin", "admin123"))
    
    conn.commit()