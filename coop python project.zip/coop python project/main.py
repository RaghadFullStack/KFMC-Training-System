import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

from database import create_connection

conn = create_connection()
conn.close()

from pages.home_page import show_home_page

if __name__ == "__main__":
    show_home_page()